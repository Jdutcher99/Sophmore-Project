<?php
    echo '<meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<meta name="description" content="Lily&#39;s Lil&#39; Garage, A good place to get some good food.">';
    echo '<meta name="keywords" content="Lily&#39;s Lil&#39; Garage, Lily&#39;s Garage, Lily&#39;s Little Garage, Restaurant, Menu, Food">';
    echo '<meta name="author" content="Jerrod Dutcher, Cameron Jordan, James Moseley, Trent Toyryla, Alden Metzmaker">';
    echo '<!-- Linked Fonts -->';
    echo '<link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">';
    echo '<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">';
    echo '<!-- Scripts -->';
    echo '<script src="Scripts/mainScripts.js" type="text/javascript"></script>';
    echo '<!-- Title -->';
    ?>