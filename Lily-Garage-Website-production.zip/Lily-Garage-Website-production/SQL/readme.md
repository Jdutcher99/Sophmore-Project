How to setup database using mySQL:

-import llg.sql into a new mySQL database

-make sure $dbLocation is set to the proper location of the database on the file "Includes/databaseHandler.php"

-the database handler is configured for XAMPP by default

-set $dbUsername and $dbPassword

-$dbName should remain constant
